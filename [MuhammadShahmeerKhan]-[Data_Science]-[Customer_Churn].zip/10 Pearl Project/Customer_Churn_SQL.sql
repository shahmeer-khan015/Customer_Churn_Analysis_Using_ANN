SELECT customerID, gender, tenure, MonthlyCharges, Contract
FROM Customers
JOIN Billing ON Customers.customerID = Billing.customerID
WHERE tenure > 12 AND MonthlyCharges > 50 AND Contract = 'One year';

INSERT INTO ChurnPrediction (customerID, prediction_result, prediction_date)
VALUES ('7590-VHVEG', 'No', '2024-11-20');


SELECT Contract, COUNT(customerID) AS churn_count
FROM Customers
JOIN ChurnPrediction ON Customers.customerID = ChurnPrediction.customerID
WHERE prediction_result = 'Yes'
GROUP BY Contract;
