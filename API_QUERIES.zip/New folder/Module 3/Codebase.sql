-- Table 1: customers
CREATE TABLE customers (
    customerID VARCHAR(10) PRIMARY KEY,  
    gender VARCHAR(6),
    SeniorCitizen SMALLINT,  
    Partner VARCHAR(3),
    Dependents VARCHAR(3),
	   tenure SMALLINT 
	);

-- Table 2: services
CREATE TABLE services (
    customerID VARCHAR(10) PRIMARY KEY, 
    PhoneService VARCHAR(3),
    MultipleLines VARCHAR(16),
    InternetService VARCHAR(12),
    OnlineSecurity VARCHAR(16),
    OnlineBackup VARCHAR(16),
    DeviceProtection VARCHAR(16),
    TechSupport VARCHAR(16),
    StreamingTV VARCHAR(16),
    StreamingMovies VARCHAR(16)
);

-- Table 3: billing
CREATE TABLE billing (
    customerID VARCHAR(10) PRIMARY KEY,  
    tenure SMALLINT,  
    Contract VARCHAR(16),
    PaperlessBilling VARCHAR(3),
    PaymentMethod VARCHAR(24),
    MonthlyCharges NUMERIC(6, 2),  
    TotalCharges NUMERIC(10, 2)  

-- Table 4: churn_predictions
CREATE TABLE churn_predictions (
    customerID VARCHAR(10) PRIMARY KEY,  
    churn VARCHAR(3),  
    predicted_churn VARCHAR(3)  -- predicted churn label from model
);




-- Load data into Customers table
COPY Customers (customerID, gender, SeniorCitizen, Partner, Dependents,tenure)
FROM 'path//' DELIMITER ',' CSV HEADER;

-- -- Load data into Services table
COPY Services (customerID, PhoneService, MultipleLines, InternetService, OnlineSecurity, OnlineBackup, DeviceProtection, TechSupport, StreamingTV, StreamingMovies)
FROM 'path//' DELIMITER ',' CSV HEADER;

-- -- Load data into Billing table
COPY Billing (customerID, tenure, Contract, PaperlessBilling, PaymentMethod, MonthlyCharges, TotalCharges)
FROM 'path//' DELIMITER ',' CSV HEADER;

-- -- Load data into ChurnPredictions table
COPY churn_predictions (customerID, churn, predicted_churn)
FROM 'path//' DELIMITER ',' CSV HEADER;


-- Main Queries:

-- Based churn_rate based on contract types
SELECT billing.Contract, 
       COUNT(*) AS Total_Customers, 
       SUM(CASE WHEN churn_predictions.churn = 'Yes' THEN 1 ELSE 0 END) AS Churned_Customers,
       ROUND(SUM(CASE WHEN churn_predictions.churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS Churn_Rate
FROM customers
JOIN churn_predictions ON customers.customerID = churn_predictions.customerID
JOIN billing ON customers.customerID = billing.customerID
GROUP BY billing.Contract;

-- Tenure/Monthly Charges based on contracts:
SELECT billing.Contract, 
       ROUND(AVG(billing.MonthlyCharges), 2) AS Avg_Monthly_Charges,
       ROUND(AVG(billing.tenure), 2) AS Avg_Tenure
FROM billing
JOIN customers ON billing.customerID = customers.customerID
GROUP BY billing.Contract;

-- Feature Correlations with churn
SELECT churn, 
       ROUND(AVG(tenure), 2) AS Avg_Tenure,
       ROUND(AVG(MonthlyCharges), 2) AS Avg_Monthly_Charges,
       ROUND(AVG(TotalCharges::NUMERIC), 2) AS Avg_Total_Charges
FROM billing
JOIN churn_predictions ON billing.customerID = churn_predictions.customerID
GROUP BY churn;


-- Payment based on churn:
SELECT billing.PaymentMethod, 
       COUNT(*) AS Total_Customers, 
       SUM(CASE WHEN churn_predictions.churn = 'Yes' THEN 1 ELSE 0 END) AS Churned_Customers,
       ROUND(SUM(CASE WHEN churn_predictions.churn = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS Churn_Rate
FROM billing
JOIN churn_predictions ON billing.customerID = churn_predictions.customerID
GROUP BY billing.PaymentMethod;

-- monthly charges based on internet service
SELECT services.InternetService, 
       services.PhoneService, 
       services.MultipleLines, 
       ROUND(AVG(billing.MonthlyCharges), 2) AS Avg_Monthly_Charges
FROM billing
JOIN services ON billing.customerID = services.customerID
GROUP BY services.InternetService, services.PhoneService, services.MultipleLines;

-- tenure based on contract
SELECT billing.Contract, 
       ROUND(AVG(billing.tenure), 2) AS Avg_Tenure,
       COUNT(*) AS Total_Customers
FROM billing
GROUP BY billing.Contract;

-- Services Usage and Churn Correlation
SELECT services.TechSupport, 
       services.OnlineSecurity, 
       COUNT(*) AS Total_Customers, 
       SUM(CASE WHEN churn_predictions.churn = 'Yes' THEN 1 ELSE 0 END) AS Churned_Customers
FROM services
JOIN churn_predictions ON services.customerID = churn_predictions.customerID
GROUP BY services.TechSupport, services.OnlineSecurity;




